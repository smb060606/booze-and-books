<script lang="ts">
	import Signup from '../../../components/auth/Signup.svelte';
</script>

<svelte:head>
	<title>Create Account - Booze and Books</title>
	<meta name="description" content="Join our literary community and start swapping books" />
</svelte:head>

<Signup />